odoo.define('nepali_datepicker.nepali_datepicker', function (require) {
    "use strict";

    var core = require('web.core');
    var fieldRegistry = require('web.field_registry');
    var AbstractField = require('web.AbstractField');
    var fieldUtils = require('web.field_utils');

    var NepaliDateField = AbstractField.extend({
        template: 'NepaliDateField',
        className: 'o_field_nepali_datepicker',
        events: _.extend({}, AbstractField.prototype.events, {
            'change .nepali_datepicker_input': '_onChange',
        }),
        _renderEdit: function () {
            this.$el.html('<input type="text" class="nepali_datepicker_input" />');
            this.$('.nepali_datepicker_input').datepicker();
        },
        _onChange: function (e) {
            this._setValue(e.target.value);
        },
    });

    fieldRegistry.add('nepali_datepicker', NepaliDateField);
});