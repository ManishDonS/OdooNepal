{
    'name': 'Nepali Datepicker Integration',
    'version': '1.0',
    'category': 'Tools',
    'summary': 'Integrate Nepali Datepicker in Odoo',
    'description': "This module integrates Leapfrog's Nepali Datepicker in Odoo 17.",
    'author': 'Manish Lama',
    'website': 'http://www.yourwebsite.com',
    'depends': ['base'],
    'data': [
        'views/nepali_datepicker_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'nepali_datepicker/static/src/js/nepali_datepicker.js',
            'nepali_datepicker/static/src/css/nepali_datepicker.css',
        ],
    },
    'installable': True,
    'application': False,
}