from odoo import models, fields

class NepaliDatepickerModel(models.Model):
    _name = 'nepali.datepicker.model'
    _description = 'Nepali Datepicker Model'

    name = fields.Char(string='Name')
    nepali_date = fields.Char(string='Nepali Date')