odoo.define('nepali_datepicker.nepali_datepicker', function (require) {
    "use strict";

    var fieldRegistry = require('web.field_registry');
    var FieldDate = require('web.basic_fields').FieldDate;

    var NepaliDateField = FieldDate.extend({
        _render: function () {
            this._super.apply(this, arguments);
            this.$input.nepaliDatePicker();
        },
    });

    fieldRegistry.add('nepali_datepicker', NepaliDateField);
});
