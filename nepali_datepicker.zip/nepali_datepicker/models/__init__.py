# models/__init__.py
from . import nepali_datepicker_model

# models/nepali_datepicker_model.py
from odoo import models, fields

class NepaliDatepickerModel(models.Model):
    _name = 'nepali.datepicker.model'
    _description = 'Model to demonstrate Nepali Datepicker integration'

    name = fields.Char(string='Name')
    nepali_date = fields.Date(string='Nepali Date')
