from odoo import models, fields, api

class PaymentAcquirer(models.Model):
    _name = 'payment.acquirer'
    _description = 'Payment Acquirer'

    name = fields.Char(string='Name', required=True)
    provider = fields.Selection(selection=[('esewa', 'Esewa')], string='Provider', required=True)
    # Add other fields and methods as needed
