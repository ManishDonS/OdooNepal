from odoo import models

class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _esewa_form_get_tx_from_data(self, data):
        # Logic to handle transaction data from eSewa
        pass

    def _esewa_form_validate(self, data):
        # Logic to validate eSewa transaction
        pass
