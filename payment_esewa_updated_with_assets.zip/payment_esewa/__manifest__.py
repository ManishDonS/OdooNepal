# -*- coding: utf-8 -*-
{
    'name': 'Payment Esewa',
    'version': '1.0',
    'category': 'Accounting/Payment',
    'summary': 'Integrate your Odoo with the Esewa payment gateway',
    'description':"""
        Custom module for integrating Esewa payment gateway in Odoo 17.
    """,
    'depends': ['base', 'payment'],
    'data': [
        'security/ir.model.access.csv',
        'views/payment_acquirer_templates.xml',
        'views/payment_acquirer_view.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'assets': {
        'web.assets_backend': [
            'payment_esewa/static/src/css/payment_esewa.css',
            'payment_esewa/static/src/js/payment_esewa.js',
        ],
    },
    'license': 'LGPL-3',
}
