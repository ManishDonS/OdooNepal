from odoo import http

class EsewaController(http.Controller):

    @http.route('/payment/esewa/return', type='http', auth='public', csrf=False)
    def esewa_return(self, **post):
        # Handle eSewa return URL logic here
        return http.request.redirect('/payment/process')
